Boa noite professor Jurair, tudo bem?

Eu nao consegui anexar o video do trabalho no teams por ser um video com tamanho grande.Entao eu anexo o link para acessar o meu google drive para assistir e/ou baixar os arquivos.
Ambos os 2 videos que tentei explicar e anexar, com tempos de duração diferentes. o mais curtos tem 20 minutos e mesmo assim eu nao consegui anexar na aba do microsoft teams no arquivo ZIP.
Pode escolher a seua preferencia ou as duas caso precisar saber com mais detalhes. O video mais longo possui mais detalhes.
Att

ernst neto

link:
https://drive.google.com/drive/folders/1Q02kq7uSOlVlubNOPWI_i1SUfwKAOBw7?usp=sharing