drop schema if exists sistema_imobiliario;
create database if not exists sistema_imobiliario;
use sistema_imobiliario;
drop table if exists Cliente_proprietario;
create table if not exists Cliente_proprietario(
	nome_proprietario varchar(100) not null,
    estado_civil varchar(50) not null,
    CPF_proprietario varchar(11) not null,
    telefone_proprietario varchar(100) not null,
    email varchar(100) null,
    unique(CPF_proprietario),
    primary key(CPF_proprietario)
);
INSERT INTO Cliente_proprietario VALUES('Joao','solteiro','12','24248888','joao@cefet.br');
drop table if exists Cliente_inquilino;
create table if not exists Cliente_inquilino(
	nome_inquilino varchar(100) not null,
    estado_civil varchar(50) not null,
    CPF_inquilino varchar(11) not null,
    telefone_inquilino varchar(100) not null,
	profissao varchar(50) not null,
    renda_familiar double(250,2) not null check(renda_familiar > 0),
    nome_fiadores varchar(400) not null,
    telefone_fiadores varchar(200) not null,
    saldo_banco_fiadores double(250,2) not null check(saldo_banco_fiadores > 0),
    email varchar(100) null,
    unique(CPF_inquilino),
    primary key(CPF_inquilino)
);
INSERT INTO Cliente_inquilino VALUES('Neto', 'casado', '16', '25253030', 'programador', 10000.0, 'maria e alexandre', '20001000 e 25253030', 12000.0, 'ernstneto@cefet.br');
drop table if exists Corretor;
create table if not exists Corretor(
	nome_corretor varchar(200) not null,
    CRECI varchar(20) not null,
    telefone_corretor varchar(100) not null,
    data_inicio date not null,
    valor_comissao double(255,2) not null check(valor_comissao > 0.0),
    unique(CRECI),
    primary key(CRECI)
);
INSERT INTO Corretor VALUES ('Carlos','20','24242480','2018-05-12',350.0);
drop table if exists Imovel;
create table if not exists Imovel(
	id_imovel integer auto_increment not null,
    numero_quartos integer not null check(numero_quartos > 0),
    numero_vagas integer not null check(numero_vagas >= 0),
    area_construida double(255,2) not null,
    status_imovel varchar(100) not null default 'livre',
    `nome_dono` varchar(200) not null,
    `CPF_dono` varchar(15) not null,
    `data_registro` date not null,
    `certidao_registro` varchar(100) not null,
    `endereco` varchar(300) not null,
    `valor_aluguel` double(255,2) not null check(`valor_aluguel` > 0.0),
    unique(`certidao_registro`),
    primary key(id_imovel,`certidao_registro`,`CPF_dono`),
    constraint `Imovel_ibfk_1` foreign key(`CPF_dono`) references `Cliente_proprietario`(`CPF_proprietario`) ON DELETE cascade on update cascade
);
INSERT INTO Imovel (numero_quartos,numero_vagas,area_construida,nome_dono,CPF_dono,data_registro,certidao_registro,endereco,valor_aluguel) VALUES (3, 2, 75.5, 'Joao', '12', '2014-08-10', '120', 'rua do imperador 20', 1200.0);
drop table if exists Visita_imovel;
create table if not exists Visita_imovel(
	id_visita integer auto_increment not null,
	nome_corretor varchar(200) not null,
    CRECI varchar(100) not null,
    nome_cliente varchar(200) not null,
    CPF_cliente varchar(15) not null,
    data_marcada datetime not null,
    id_imovel integer not null,
    primary key(id_visita,id_imovel,CPF_cliente,CRECI),
    constraint `Visita_imovel_ifbk_1` foreign key(id_imovel) references Imovel(id_imovel) ON DELETE cascade on update cascade,
    constraint `Visita_imovel_ifbk_2` foreign key(CPF_cliente) REFERENCES Cliente_inquilino(CPF_inquilino) ON DELETE cascade on update cascade,
    constraint `Visita_imovel_ifbk_3` foreign key(CRECI) REFERENCES Corretor(CRECI) ON DELETE cascade on update cascade
);
INSERT INTO Visita_imovel (nome_corretor,CRECI,nome_cliente,CPF_cliente,data_marcada,id_imovel) VALUES ('Carlos','20','Neto','16','2022-03-14',1);
drop table if exists Oferta_aluguel;
create table if not exists Oferta_aluguel(
	id_oferta integer auto_increment not null,
	id_imovel integer not null,
    nome_cliente varchar(200) not null,
    CPF_cliente varchar(15) not null,
    nome_corretor varchar(200) not null,
    CRECI varchar(20) not null,
    valor_original double(255,2) not null check(valor_original > 0.0),
    valor_oferta double(255,2) not null check(valor_oferta > 0.0),
    valor_comissao double(255,2) not null check(valor_comissao > 0.0),
    data_oferta date not null,
    primary key(id_oferta,id_imovel,CPF_cliente,CRECI),
    constraint `Oferta_imovel_ifbk_1` foreign key(id_imovel) references Imovel(id_imovel) ON DELETE cascade on update cascade,
    constraint `Oferta_imovel_ifbk_2` foreign key(CPF_cliente) references Cliente_inquilino(CPF_inquilino) ON DELETE cascade on update cascade,
    constraint `Oferta_imovel_ifbk_3` foreign key(CRECI) references Corretor(CRECI) ON DELETE cascade on update cascade
);
INSERT INTO Oferta_aluguel (id_imovel,nome_cliente,CPF_cliente,nome_corretor,CRECI,valor_original,valor_oferta,valor_comissao,data_oferta) VALUES (1,'Neto','16','Carlos','20',1200.0,1000.0,350.0,'2022-03-14');
drop table if exists Contrato_aluguel; 
create table if not exists Contrato_aluguel(
	id_contrato integer auto_increment not null,
    id_imovel integer not null,
    nome_inquilino varchar(200) not null,
    CPF_inquilino varchar(20) not null,
    nome_proprietario varchar(200) not null,
    CPF_proprietario varchar(20) not null,
    data_contrato date not null,
    duracao_contrato double(255,2) not null default(2.5),
    valor_aluguel double(255,2) not null,
    primary key(id_contrato,id_imovel,CPF_inquilino,CPF_proprietario),
    constraint `Contrato_aluguel_ifbk_1` foreign key(id_imovel) references Imovel(id_imovel) on delete cascade on update cascade,
    constraint `Contrato_aluguel_ifbk_2` foreign key(CPF_inquilino) references Cliente_inquilino(CPF_inquilino) on delete cascade on update cascade,
    constraint `Contrato_aluguel_ifbk_3` foreign key(CPF_proprietario) references Cliente_proprietario(CPF_proprietario) ON DELETE cascade on update cascade
);

