#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "inserir.h"
#include "buscar.h"
#include <mysql/mysql.h>
#include "administrador.h"


void inserir_aluno(MYSQL *conn){
	printf("Digite a matricula e nome do aluno:\n");
	printf("Matricula: ");
	char matricula[15];
	scanf("%s", matricula);
	printf("%s\n",matricula);
	int resposta = buscar_aluno(conn,matricula);
	if(resposta == 0){
		printf("Encontrou aluno no sistema!\nInserccao do aluno abortado!\n");
	}
	else if(resposta == 1){
		printf("Aluno nao esta no sistema!Insercao do aluno no sistema da biblioteca!\n");
		//inserir aluno
		if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
			printf("Conectado com sucesso!\n");
			printf("Nome: ");
			char nome[100];
			scanf("%s",nome);
			char query[300];
			sprintf(query,"INSERT INTO Aluno (matricula,nome) values (AES_ENCRYPT('%s','cefet10'), AES_ENCRYPT('%s','cefet10'));",matricula,nome);
			int res = mysql_query(conn,query);
			if(!res){
				printf("Registro inseridos %ld\n",mysql_affected_rows(conn));
			}
			else{
				printf("Erro na insercao %d : %s\n",mysql_errno(conn),mysql_error(conn));
			}
		}
		else{
			printf("Falha de conexao!\n");
			printf("Erro %d : %s\n",mysql_errno(conn),mysql_error(conn));
		}
	}
	mysql_close(conn);
	printf("\n");
}

void inserir_livro(MYSQL *conn){
	printf("Digite o id do livro:\n");
	printf("ID: ");
	char id_livro[100];
	scanf("%s",id_livro);
	int resposta = buscar_livro(conn,id_livro, "id_livro");
	if(resposta == 0){
		printf("Encontrou livro no sistema!\n");
	}
	else if(resposta == 1){
		printf("Livro nao esta no sistema!Insercao do livro no sistema da biblioteca!\n");
		printf("Digite o nome do livro: ");
		char nome[100];
		scanf("%s",nome);
		printf("Digite o ano de publicacao: ");
		char ano[10];
		scanf("%s",ano);
		printf("Digite a categoria do livro: ");
		char categoria[100];
		scanf("%s",categoria);
		//inserir livro
		char estado[] = "livre";
		int res;
		if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
			printf("Conectado com sucesso!\n");
			char query[400];
			sprintf(query,"insert into Livro (nome,ano,categoria,estado) values ('%s','%s','%s','%s');",nome,ano,categoria,estado);
			res = mysql_query(conn,query);
			if(!res){
				printf("Registro do livro inseridos: %ld\n",mysql_affected_rows(conn));
			}
			else{
				printf("Erro na insercao %d : %s\n",mysql_errno(conn),mysql_error(conn));
			}
		}
		else{
			printf("falha de conexao!\n");
			printf("Erro %d : %s\n",mysql_errno(conn),mysql_error(conn));
		}
	}
	mysql_close(conn);
	printf("\n");
}

void inserir_sala(MYSQL *conn){
	printf("Digite o id da sala:\n");
	printf("ID: ");
	char id_sala[100];
	scanf("%s",id_sala);
	int resposta = buscar_sala(conn,id_sala);
	if(resposta == 0){
		printf("Encontrou sala no sistema!\n");
	}
	else if(resposta == 1){
		printf("Sala nao esta no sistema!Insercao da sala no sistema da biblioteca!\n");
		//inserir sala
		int res;
		if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
			printf("Conectado com sucesso!\n");
			char query[300];
			sprintf(query,"insert into Sala (estado) value ('livre');");
			res = mysql_query(conn,query);
			if(!res){
				printf("Registro do livro inseridos: %ld\n",mysql_affected_rows(conn));
			}
			else{
				printf("Erro na insercao %d : %s\n",mysql_errno(conn),mysql_error(conn));
			}
		}
		else{
			printf("falha de conexao!\n");
			printf("Erro %d : %s\n",mysql_errno(conn),mysql_error(conn));
		}
	}
	mysql_close(conn);
	printf("\n");
}

void inserir_armario(MYSQL *conn){
	printf("Digite o id do armario:\n");
	printf("ID: ");
	char id_armario[100];
	scanf("%s",id_armario);
	int resposta = buscar_armario(conn,id_armario);
	if(resposta == 0){
		printf("Encontrou armario no sistema!\n");
	}
	else if(resposta == 1){
		printf("Armario nao esta no sistema!Insercao do armario no sistema da biblioteca!\n");
		//inserir armario
		printf("Sala nao esta no sistema!Insercao da sala no sistema da biblioteca!\n");
		//inserir sala
		int res;
		if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
			printf("Conectado com sucesso!\n");
			char query[] = "insert into Armario (estado) values ('livre');";
			res = mysql_query(conn,query);
			if(!res){
				printf("Registro do livro inseridos: %ld\n",mysql_affected_rows(conn));
			}
			else{
				printf("Erro na insercao %d : %s\n",mysql_errno(conn),mysql_error(conn));
			}
			mysql_close(conn);
		}
		else{
			printf("falha de conexao!\n");
			printf("Erro %d : %s\n",mysql_errno(conn),mysql_error(conn));
		}
	}
	printf("\n");
}

void inserir_computador(MYSQL *conn){
	printf("Digite o id do computador:\n");
	printf("ID: ");
	char id_computador[100];
	scanf("%s",id_computador);
	int resposta = buscar_computador(conn,id_computador);
	if(resposta == 0){
		printf("Encontrou computador no sistema!\n");
	}
	else if(resposta == 1){
		printf("Computador nao esta no sistema!Insercao do computador no sistema da biblioteca!\n");
		//inserir computador
		int res;
		if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
			printf("Conectado com sucesso!\n");
			char query[] = "insert into Computador(estado) values ('livre');";
			res = mysql_query(conn,query);
			if(!res){
				printf("Registro do livro inseridos: %ld\n",mysql_affected_rows(conn));
			}
			else{
				printf("Erro na insercao %d : %s\n",mysql_errno(conn),mysql_error(conn));
			}
		}
		else{
			printf("falha de conexao!\n");
			printf("Erro %d : %s\n",mysql_errno(conn),mysql_error(conn));
		}
	}
	printf("\n");
	mysql_close(conn);	
}

