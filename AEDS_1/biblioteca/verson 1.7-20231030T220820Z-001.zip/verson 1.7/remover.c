#ifndef REMOVER_H
#define REMOVER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "buscar.h"
#include <mysql/mysql.h>
#include "remover.h"
#include "administrador.h"

void remover_aluno(MYSQL *conn){
	printf("Digite a matricula do aluno:\n");
	printf("Matricula: ");
	char matricula[15];
	scanf("%s",matricula);
	int resposta = buscar_aluno(conn,matricula);
	printf("%d\n",resposta);
	if(resposta == 1){
		printf("Encontrou aluno no sistema!\n");
		printf("Verificar pedencias do aluno!\n");
		int resp2 = 0;
		printf("%s\n",matricula);
		resp2 += buscar_aluno_biblioteca_id_livro(conn,matricula);
		resp2 += buscar_aluno_biblioteca_id_sala(conn,matricula);
		resp2 += buscar_aluno_biblioteca_id_armario(conn,matricula);
		resp2 += buscar_aluno_biblioteca_id_computador(conn,matricula);
		if(resp2 != 4){
			printf("Aluno com pedencias!\n");
		}
		else if(resp2 == 4){
			if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
				printf("Conectado com sucesso!\n");
				char query[300];
				sprintf(query,"DELETE FROM Aluno where matricula = AES_ENCRYPT('%s','cefet10');",matricula);
				int res = mysql_query(conn,query);
				if(!res){
					printf("Registro removido %ld\n",mysql_affected_rows(conn));
				}
				else{
					printf("Erro na remocao %d : %s\n",mysql_errno(conn),mysql_error(conn));
				}
			}
			else{
			printf("Falha de conexao!\n");
			printf("Erro %d : %s\n",mysql_errno(conn),mysql_error(conn));
			}
		}
	}
	else if(resposta == 0){
		printf("Aluno nao esta no sistema!remocao do aluno no sistema da biblioteca abortado!\n");
	}
	mysql_close(conn);
	printf("\n");
}
void remover_livro(MYSQL *conn){
	printf("Digite o ID do livro:\n");
	printf("ID: ");
	char id_livro[100];
	scanf("%s",id_livro);
	int resposta = buscar_livro(conn,id_livro, "id_livro");
	if(resposta == 1){
		printf("Encontrou aluno no sistema!\n");
		if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
			printf("Conectado com sucesso!\n");
			char query[300];
			sprintf(query,"DELETE FROM Livro where id_livro = '%s' and estado = 'livre' and id_aluno IS NULL;",id_livro);
			int res = mysql_query(conn,query);
			if(!res){
				printf("Registro removido %ld\n",mysql_affected_rows(conn));
			}
			else{
				printf("Erro na remocao %d : %s\n",mysql_errno(conn),mysql_error(conn));
			}
		}
		else{
			printf("Falha de conexao!\n");
			printf("Erro %d : %s\n",mysql_errno(conn),mysql_error(conn));
		}
	}
	else if(resposta == 0){
		printf("Livro nao esta no sistema!remocao do livro no sistema da biblioteca abortado!\n");
	}
	mysql_close(conn);
	printf("\n");
}
void remover_sala(MYSQL *conn){
	//etapa de login
	printf("Digite o ID da sala:\n");
	printf("ID: ");
	char id_sala[100];
	scanf("%s",id_sala);
	int resposta = buscar_sala(conn,id_sala);
	if(resposta == 1){
		printf("Encontrou aluno no sistema!\n");
		if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
			printf("Conectado com sucesso!\n");
			char query[300];
			sprintf(query,"DELETE FROM Sala where id_sala = '%s' and estado = 'livre' and id_aluno IS NULL;",id_sala);
			int res = mysql_query(conn,query);
			if(!res){
				printf("Registro removido %ld\n",mysql_affected_rows(conn));
			}
			else{
				printf("Erro na remocao %d : %s\n",mysql_errno(conn),mysql_error(conn));
			}
		}
		else{
			printf("Falha de conexao!\n");
			printf("Erro %d : %s\n",mysql_errno(conn),mysql_error(conn));
		}
	}
	else if(resposta == 0){
		printf("Sala nao esta no sistema!remocao do sala no sistema da biblioteca abortado!\n");
	}
	mysql_close(conn);
	printf("\n");
	//caso contrario, a resposta de login incorreto ou falha
}
void remover_armario(MYSQL *conn){
	printf("Digite o ID do armario:\n");
	printf("ID: ");
	char id_armario[100];
	scanf("%s",id_armario);
	int resposta = buscar_armario(conn,id_armario);
	if(resposta == 1){
		printf("Encontrou aluno no sistema!\n");
		if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
			printf("Conectado com sucesso!\n");
			char query[300];
			sprintf(query,"DELETE FROM Armario where id_armario = '%s' and estado = 'livre' and id_aluno IS NULL",id_armario);
			int res = mysql_query(conn,query);
			if(!res){
				printf("Registro removido %ld\n",mysql_affected_rows(conn));
			}
			else{
				printf("Erro na remocao %d : %s\n",mysql_errno(conn),mysql_error(conn));
			}
		}
		else{
			printf("Falha de conexao!\n");
			printf("Erro %d : %s\n",mysql_errno(conn),mysql_error(conn));
		}
	}
	else if(resposta == 0){
		printf("Armario nao esta no sistema!remocao do armario no sistema da biblioteca abortado!\n");
	}
	mysql_close(conn);
	printf("\n");
}

void remover_computador(MYSQL *conn){
	printf("Digite o ID do computador:\n");
	printf("ID: ");
	char id_computador[100];
	scanf("%s",id_computador);
	int resposta = buscar_computador(conn,id_computador);
	if(resposta == 1){
		printf("Encontrou aluno no sistema!\n");
		if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
			printf("Conectado com sucesso!\n");
			char query[300];
			sprintf(query,"DELETE FROM Computador where id_computador = '%s' and estado = 'livre' and id_aluno IS NULL;",id_computador);
			int res = mysql_query(conn,query);
			if(!res){
				printf("Registro removido %ld\n",mysql_affected_rows(conn));
			}
			else{
				printf("Erro na remocao %d : %s\n",mysql_errno(conn),mysql_error(conn));
			}
		}
		else{
			printf("Falha de conexao!\n");
			printf("Erro %d : %s\n",mysql_errno(conn),mysql_error(conn));
		}
	}
	else if(resposta == 0){
		printf("Computador nao esta no sistema!remocao do computador no sistema da biblioteca abortado!\n");
	}
	mysql_close(conn);
	printf("\n");
}

#endif
