-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: biblioteca
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Administrador`
--

DROP TABLE IF EXISTS `Administrador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Administrador` (
  `login` varbinary(255) NOT NULL,
  `senha` varbinary(255) NOT NULL,
  PRIMARY KEY (`login`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Administrador`
--

LOCK TABLES `Administrador` WRITE;
/*!40000 ALTER TABLE `Administrador` DISABLE KEYS */;
INSERT INTO `Administrador` VALUES (_binary 'rq\�\�\�\�``\��\r��',_binary 'Iz\�^\�\0j�L\�<1O');
/*!40000 ALTER TABLE `Administrador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Aluno`
--

DROP TABLE IF EXISTS `Aluno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Aluno` (
  `matricula` varbinary(255) NOT NULL,
  `nome` varbinary(255) DEFAULT NULL,
  PRIMARY KEY (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Aluno`
--

LOCK TABLES `Aluno` WRITE;
/*!40000 ALTER TABLE `Aluno` DISABLE KEYS */;
INSERT INTO `Aluno` VALUES (_binary 'J\��\'�7��\��>�\�',_binary 'ַ�2Y\��\�r2J\�}'),(_binary '|TJ���à>�0�w�\�',_binary '�-F�w�\�t\��\�'),(_binary '�\�\�L�\�xH\�\�^6\�',_binary 'u� \�.[�\�7��dy�'),(_binary '�D\�\���f�\���\�\�\�\�',_binary 'Q0^Xm�u\�\�\�\�\�`\�'),(_binary 'υ�\� 7��\�\�\�gI\�B',_binary '�=�f£\�\0D�+�\�U');
/*!40000 ALTER TABLE `Aluno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Armario`
--

DROP TABLE IF EXISTS `Armario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Armario` (
  `id_armario` int NOT NULL AUTO_INCREMENT,
  `estado` varchar(20) DEFAULT NULL,
  `id_aluno` varbinary(255) DEFAULT NULL,
  PRIMARY KEY (`id_armario`),
  CONSTRAINT `Armario_chk_1` CHECK (((`estado` = _utf8mb4'livre') or (`estado` = _utf8mb4'ocupado')))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Armario`
--

LOCK TABLES `Armario` WRITE;
/*!40000 ALTER TABLE `Armario` DISABLE KEYS */;
INSERT INTO `Armario` VALUES (1,'livre',NULL),(2,'livre',NULL),(3,'livre',NULL),(4,'livre',NULL),(5,'livre',NULL),(6,'livre',NULL),(7,'livre',NULL),(8,'livre',NULL),(9,'livre',NULL),(10,'livre',NULL);
/*!40000 ALTER TABLE `Armario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Computador`
--

DROP TABLE IF EXISTS `Computador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Computador` (
  `id_computador` int NOT NULL AUTO_INCREMENT,
  `estado` varchar(20) DEFAULT NULL,
  `id_aluno` varbinary(255) DEFAULT NULL,
  PRIMARY KEY (`id_computador`),
  CONSTRAINT `Computador_chk_1` CHECK (((`estado` = _utf8mb4'livre') or (`estado` = _utf8mb4'ocupado')))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Computador`
--

LOCK TABLES `Computador` WRITE;
/*!40000 ALTER TABLE `Computador` DISABLE KEYS */;
INSERT INTO `Computador` VALUES (1,'livre',NULL),(2,'livre',NULL),(3,'livre',NULL),(4,'livre',NULL),(5,'livre',NULL),(6,'livre',NULL),(7,'livre',NULL),(8,'livre',NULL),(9,'livre',NULL),(10,'livre',NULL);
/*!40000 ALTER TABLE `Computador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Livro`
--

DROP TABLE IF EXISTS `Livro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Livro` (
  `nome` varchar(100) NOT NULL,
  `ano` int NOT NULL,
  `categoria` varchar(50) NOT NULL,
  `estado` varchar(100) NOT NULL,
  `id_livro` int NOT NULL AUTO_INCREMENT,
  `id_aluno` varbinary(255) DEFAULT NULL,
  PRIMARY KEY (`id_livro`),
  CONSTRAINT `Livro_chk_1` CHECK (((`estado` = _utf8mb4'livre') or (`estado` = _utf8mb4'alugado')))
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Livro`
--

LOCK TABLES `Livro` WRITE;
/*!40000 ALTER TABLE `Livro` DISABLE KEYS */;
INSERT INTO `Livro` VALUES ('Calculo I',2022,'matematica','livre',1,NULL),('Calculo I',2022,'matematica','livre',2,NULL),('Calculo I',2022,'matematica','livre',3,NULL),('Calculo II',2022,'matematica','livre',4,NULL),('Calculo II',2022,'matematica','livre',5,NULL),('Calculo II',2022,'matematica','livre',6,NULL),('Calculo III',2022,'matematica','livre',7,NULL),('Calculo III',2022,'matematica','livre',8,NULL),('Calculo III',2022,'matematica','livre',9,NULL),('Fisica I',2018,'fisica','livre',10,NULL),('Fisica I',2018,'fisica','livre',11,NULL),('Fisica I',2018,'fisica','livre',12,NULL),('Fisica II',2018,'fisica','livre',13,NULL),('Fisica II',2018,'fisica','livre',14,NULL),('Fisica III',2018,'fisica','livre',15,NULL),('Fisica III',2018,'fisica','livre',16,NULL),('Algoritmos I',2019,'computacao','livre',17,NULL),('Algoritmos I',2019,'computacao','livre',18,NULL),('Algoritmos I',2019,'computacao','livre',19,NULL),('Algoritmos II',2019,'computacao','livre',20,NULL),('Algoritmos II',2019,'computacao','livre',21,NULL),('Algoritmos II',2019,'computacao','livre',22,NULL),('Arquitetura de computadores',2022,'computacao','livre',23,NULL),('Arquitetura de computadores',2022,'computacao','livre',24,NULL),('Arquitetura de computadores',2022,'computacao','livre',25,NULL),('Algoritmos II',2022,'computacao','livre',26,NULL),('Algoritmos II',2022,'computacao','livre',27,NULL),('Algoritmos II',2022,'computacao','livre',28,NULL);
/*!40000 ALTER TABLE `Livro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sala`
--

DROP TABLE IF EXISTS `Sala`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Sala` (
  `id_sala` int NOT NULL AUTO_INCREMENT,
  `estado` varchar(20) DEFAULT NULL,
  `id_aluno` varbinary(255) DEFAULT NULL,
  PRIMARY KEY (`id_sala`),
  CONSTRAINT `Sala_chk_1` CHECK (((`estado` = _utf8mb4'livre') or (`estado` = _utf8mb4'ocupado')))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sala`
--

LOCK TABLES `Sala` WRITE;
/*!40000 ALTER TABLE `Sala` DISABLE KEYS */;
INSERT INTO `Sala` VALUES (1,'livre',NULL),(2,'livre',NULL),(3,'livre',NULL),(4,'livre',NULL),(5,'livre',NULL);
/*!40000 ALTER TABLE `Sala` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-31 21:46:08
