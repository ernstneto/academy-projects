#ifndef ALTERAR_H
#define ALTERAR_H

#include <mysql/mysql.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "alterar.h"
#include "buscar.h"
#include "administrador.h"

void alterar_livro(MYSQL *conn){
	int res;
	int resposta;
	printf("Digite o id do livro:\n");
	printf("ID: ");
	char id_livro[100];
	scanf("%s",id_livro);
	resposta = buscar_livro(conn,id_livro, "id_livro");
	if(resposta == 1){
		int loop = 1;
		int opcao;
		while(loop){
			printf("Encontrou livro no sistema!\n");
			printf("Deseja alterar as informacoes do livro, digite 1\n");
			//printf("Deseja alterar a informacao do estado, digite 2\n");
			printf("Deseja alugar o livro, digite 2\n");
			printf("Deseja devolver o livro, digite 3\n");
			printf("Deseja voltar ao menu da biblioteca, digite 0\n");
			printf("Opcao: ");
			scanf("%d",&opcao);
			if(opcao == 0){
				loop = 0;
				printf("voltando ao menu biblioteca!\n");
				return;
			}
			else if(opcao == 1){
				printf("Digite o nome do livro: ");
				char nome[100];
				scanf("%s",nome);
				printf("Digite o ano de publicacao: ");
				char ano[10];
				scanf("%s",ano);
				printf("Digite a categoria do livro: ");
				char categoria[100];
				scanf("%s",categoria);

				//alterar livro
				int res;
				if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
					printf("Conectado com sucesso!\n");
					char query[700];
					sprintf(query,"update Livro set nome = '%s', ano = '%s', categoria = '%s' where id_livro = '%s' and id_aluno IS NULL;",nome,ano,categoria,id_livro);
					res = mysql_query(conn,query);
					if(!res){
						printf("Registro do livro inseridos: %ld\n",mysql_affected_rows(conn));
						loop = 0;
					}
					else{
						printf("Erro na insercao %d : %s\n",mysql_errno(conn),mysql_error(conn));
					}
				}
				else{
					printf("falha de conexao!\n");
					printf("Erro %d : %s\n",mysql_errno(conn),mysql_error(conn));
				}
			}
			else if(opcao == 2){
				printf("ID do aluno: ");
				char id_aluno[15];
				scanf("%s",id_aluno);
				//inserir livro
				int res;
				if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
					printf("Conectado com sucesso!\n");
					char query[500];
					sprintf(query,"update Livro set estado = 'alugado', id_aluno = AES_ENCRYPT('%s','cefet10') where id_livro = '%s' and estado = 'livre' and id_aluno IS NULL;",id_aluno,id_livro);
					res = mysql_query(conn,query);
					if(!res){
						printf("Registro do livro inseridos: %ld\n",mysql_affected_rows(conn));
						loop = 0;
					}
					else{
						printf("Erro na insercao %d : %s\n",mysql_errno(conn),mysql_error(conn));
					}
				}
				else{
					printf("falha de conexao!\n");
					printf("Erro %d : %s\n",mysql_errno(conn),mysql_error(conn));
				}
			}
			else if(opcao == 3){
				printf("Insira o ID do livro: ");
				char id_livro[100];
				scanf("%s",id_livro);
				//int res = buscar_livro_alugar(conn,id_livro);
				//if(!res){
				//printf("Livro encontrado e livre para alugar\n");
				printf("Insira a matricula do aluno: ");
				char matricula[15];
				scanf("%s",matricula);
				char query[300];
				sprintf(query,"update Livro set estado = 'livre', id_aluno = NULL where id_livro = '%s' and estado = 'alugado' and id_aluno = AES_ENCRYPT('%s','cefet10');",id_livro,matricula);
				int res2 = mysql_query(conn,query);
				if(!res2){
					printf("Registro do livro devolvido: %ld\n",mysql_affected_rows(conn));
				}
				else{
					printf("Erro na atualizacao do livro %d : %s\n",mysql_errno(conn),mysql_error(conn));
				}
				}
				else{
					printf("O livro nao esta livre!\n");
				}
			
			}
	}	
	else if(resposta == 0){
		printf("Livro nao esta no sistema!alteracao do livro no sistema da biblioteca abortado!\n");
	}
	mysql_close(conn);
}

void alterar_sala(MYSQL *conn){
	//etapa de login
	int reposta = etapa_acesso_administrador(conn);
	//Caso 0, a resposta de login correto
	if(reposta == 0){
		printf("Login com sucesso!\n");
	}
	int res;
	int resposta;
	printf("Digite o id da sala:\n");
	printf("ID: ");
	char id_sala[100];
	scanf("%s",id_sala);
	resposta = buscar_sala(conn,id_sala);
	if(resposta == 1){
		int loop = 1;
		int opcao;
		while(loop){
			printf("Encontrou sala no sistema!\n");
			printf("Deseja alterar a sala para livre, digite 1\n");
			printf("Deseja alterar a sala para ocupado, digite 2\n");
			printf("Deseja voltar ao menu da biblioteca, digite 0\n");
			printf("Opcao: ");
			scanf("%d",&opcao);
			if(opcao == 0){
				loop = 0;
				printf("voltando ao menu biblioteca!\n");
				return;
			}
			else if(opcao == 1){
				if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
					printf("Conectado com sucesso!\n");
					char query[300];
					sprintf(query,"update Sala set estado = 'livre', id_aluno = NULL where id_sala = '%s' and id_aluno IS NOT NULL;",id_sala);
					res = mysql_query(conn,query);
					if(!res){
						printf("alteracao do armario com sucesso: %ld\n",mysql_affected_rows(conn));
						loop = 0;
					}
					else{
						printf("Erro na alteracao %d : %s\n",mysql_errno(conn),mysql_error(conn));
					}	

				}
				else{
					printf("Comando invalido!\n");
				}
			}	
			
			else if(opcao == 2){
				char id_sala[100];
				printf("ID da sala: ");
				scanf("%s",id_sala);
				char matricula[15];
				printf("Matricula do aluno: ");
				scanf("%s",matricula);
				if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
					printf("Conectado com sucesso!\n");
					char query[300];
					sprintf(query,"update Sala set estado = 'ocupado', id_aluno = AES_ENCRYPT('%s','cefet10') where id_sala = '%s' and id_aluno IS NULL;",matricula,id_sala);
					res = mysql_query(conn,query);
					if(!res){
						printf("alteracao do armario com sucesso: %ld\n",mysql_affected_rows(conn));
						loop = 0;
					}
					else{
						printf("Erro na alteracao %d : %s\n",mysql_errno(conn),mysql_error(conn));
					}	
				}
				else{
					printf("Comando invalido!\n");
				}
					
			}
			else{
				printf("Comando invalido!\n");
			}
		}
	}
	else if(resposta == 0){
		printf("Livro nao esta no sistema!alteracao do livro no sistema da biblioteca abortado!\n");
	}
	mysql_close(conn);
}

void alterar_computador(MYSQL *conn){
	int res;
	int resposta;
	printf("Digite o id do livro:\n");
	printf("ID: ");
	char id_computador[100];
	scanf("%s",id_computador);
	resposta = buscar_computador(conn,id_computador);
	if(resposta == 1){
		int loop = 1;
		int opcao;
		while(loop){
			printf("Encontrou computador no sistema!\n");
			printf("Deseja alterar o estado do computador, digite 1\n");
			printf("Deseja voltar ao menu da biblioteca, digite 0\n");
			printf("Opcao: ");
			scanf("%d",&opcao);
			if(opcao == 0){
				loop = 0;
				printf("voltando ao menu biblioteca!\n");
				return;
			}
			else if(opcao == 1){
				//alterar computador
				int res;
				if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
					printf("Conectado com sucesso!\n");
					printf("Deseja colocar o computador como livre, digite 1\n");
					printf("Deseja colocar o computador como ocupado, digite 2\n");
					printf("Caso deseja abortar, digite 0\n");
					printf("Opcao: ");
					int opcao;
					scanf("%d",&opcao);
					if(opcao == 1){
						char query[300]; 
						sprintf(query,"update Computador set estado = 'livre', id_aluno = NULL where id_computador = '%s' and id_aluno IS NOT NULL;",id_computador);
						res = mysql_query(conn,query);
						if(!res){
							printf("Registro do livro inseridos: %ld\n",mysql_affected_rows(conn));
							loop = 0;
						}
						else{
							printf("Erro na insercao %d : %s\n",mysql_errno(conn),mysql_error(conn));
						}	
					}
					else if(opcao == 2){
						char matricula[15];
						printf("Matricula do aluno: ");
						scanf("%s",matricula);
						char query[300];
						sprintf(query,"update Computador set estado = 'ocupado', id_aluno = AES_ENCRYPT('%s','cefet10') where id_computador = '%s'and id_aluno IS NULL;",matricula,id_computador);
						res = mysql_query(conn,query);
						if(!res){
							printf("Registro do livro inseridos: %ld\n",mysql_affected_rows(conn));
							loop = 0;
						}
						else{
							printf("Erro na insercao %d : %s\n",mysql_errno(conn),mysql_error(conn));
						}	
					}
					else if(opcao == 0){
						printf("retornar ao menu biblioteca!\n");
					}
				}
				else{
					printf("falha de conexao!\n");
					printf("Erro %d : %s\n",mysql_errno(conn),mysql_error(conn));
				}
			}
			else{
				printf("Comando invalido!\n");
			}
		}
		
	}
	else if(resposta == 0){
		printf("Livro nao esta no sistema!alteracao do livro no sistema da biblioteca abortado!\n");
	}
	mysql_close(conn);
}

void alterar_armario(MYSQL *conn){
	int res;
	int resposta;
	printf("Digite o id do armario:\n");
	printf("ID: ");
	char id_armario[100];
	scanf("%s",id_armario);
	resposta = buscar_armario(conn,id_armario);
	if(resposta == 1){
		int loop = 1;
		int opcao;
		while(loop){
			printf("Encontrou armario no sistema!\n");
			printf("Deseja alterar armario para livre, digite 1\n");
			printf("Deseja alterar armario para ocupado, digite 2\n");
			printf("Deseja voltar ao menu da biblioteca, digite 0\n");
			printf("Opcao: ");
			scanf("%d",&opcao);
			if(opcao == 0){
				loop = 0;
				printf("voltando ao menu biblioteca!\n");
				return;
			}
			else if(opcao == 1){
				if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
					printf("Conectado com sucesso!\n");
					char query[300];
					sprintf(query,"update Armario set estado = 'livre', id_aluno = NULL where id_armario = '%s';",id_armario);
					res = mysql_query(conn,query);
					if(!res){
						printf("alteracao do armario com sucesso: %ld\n",mysql_affected_rows(conn));
						loop = 0;
					}
					else{
						printf("Erro na alteracao %d : %s\n",mysql_errno(conn),mysql_error(conn));
					}	

				}
			}
			else if(opcao == 2){
				char matricula[15];
				printf("ID do aluno: ");
				scanf("%s",matricula);
				if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
					printf("Conectado com sucesso!\n");
					char query[300];
					sprintf(query,"update Armario set estado = 'ocupado', id_aluno = AES_ENCRYPT('%s','cefet10') where id_armario = '%s' and id_aluno IS NULL;",matricula,id_armario);
					res = mysql_query(conn,query);
					if(!res){
						printf("alteracao do armario com sucesso: %ld\n",mysql_affected_rows(conn));
						loop = 0;
					}
					else{
						printf("Erro na alteracao %d : %s\n",mysql_errno(conn),mysql_error(conn));
					}	
				}	
			}
			else{
				printf("Comando invalido!\n");
			}
		}
	}
	else if(resposta == 0){
		printf("Livro nao esta no sistema!alteracao do livro no sistema da biblioteca abortado!\n");
	}
	mysql_close(conn);
}

void alterar_aluno(MYSQL *conn){
	int res;
	int resposta;
	printf("Digite a matricula do aluno: ");
	char matricula[15];
	scanf("%s",matricula);
	printf("%s\n",matricula);
	resposta = buscar_aluno(conn,matricula);
	if(resposta == 1){
		int loop = 1;
		int opcao;
		while(loop){
			printf("Encontrou aluno no sistema!\n");
			printf("Deseja alterar nome do aluno, digite 1\n");
			printf("Deseja voltar ao espaco alunos, digite 0\n");
			printf("Opcao: ");
			scanf("%d",&opcao);
			if(opcao == 0){
				//loop = 0;
				return;
			}
			else if(opcao == 1){
				if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
					printf("Conectado com sucesso!\n");
					char nome[100];
					printf("Nome: ");
					scanf("%s",nome);
					printf("%s\n",nome);
					char query[300];
					sprintf(query,"update Aluno set nome = AES_ENCRYPT('%s','cefet10') where matricula = AES_ENCRYPT('%s','cefet10');",nome,matricula);
					res = mysql_query(conn,query);
					if(!res){
						printf("alteracao do armario com sucesso: %ld\n",mysql_affected_rows(conn));
						loop = 0;
					}
					else{
						printf("Erro na alteracao %d : %s\n",mysql_errno(conn),mysql_error(conn));
					}
				}
			}
			else{
				printf("Comando invalido!\n");
			}
		}
	}
	else if(resposta == 0){
		printf("Aluno nao estao no sistema!\n");
	}
	mysql_close(conn);
}

#endif
