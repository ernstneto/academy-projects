#ifndef INSERIR_H
#define INSERIR_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "buscar.h"
#include <mysql/mysql.h>
#include "administrador.h"
//inserir novo aluno apos verificacao de existe o aluno no sistema
void inserir_aluno(MYSQL *conn);
//inserir novo livro apos verificacao de existe o livro no sistema
void inserir_livro(MYSQL *conn);
//inserir nova sala apos verificacao de existe a sala no sistema
void inserir_sala(MYSQL *conn);
//inserir novo armario apos verificacao de existe o armario no sistema
void inserir_armario(MYSQL *conn);
//inserir novo computador apos verificacao de existe o computador no sistema
void inserir_computador(MYSQL *conn);

#endif
