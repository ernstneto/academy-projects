#ifndef ALTERAR_H
#define ALTERAR_H

#include <mysql/mysql.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "buscar.h"
#include "administrador.h"
//alterar dados do livro, possibilidade de trocar informacoes e estado dos livros
void alterar_livro(MYSQL *conn);
//alterar dados da sala, possibilidade de trocar estado e id do aluno sendo ocupado
void alterar_sala(MYSQL *conn);
//alterar dados do computador, possibilidade de trocar estado e id do aluno sendo ocupado
void alterar_computador(MYSQL *conn);
//alterar dados do armario, possibilidade de trocar estado e id do aluno sendo ocupado
void alterar_armario(MYSQL *conn);
//alterar dados do aluno, possibilidade de trocar estado e id do aluno sendo ocupado
void alterar_aluno(MYSQL *conn);

#endif
