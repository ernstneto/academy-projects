#ifndef REMOVER_H
#define REMOVER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "buscar.h"
#include <mysql/mysql.h>
#include "administrador.h"
//remover o aluno apos a verificao de pedencias na biblioteca
void remover_aluno(MYSQL *conn);
//remover o livro apos a verificacao de se o livro esteja sendo usado ou alugado por um aluno
void remover_livro(MYSQL *conn);
//remover a sala apos a verificacao de se a sala esteja sendo usado ou alugado por um aluno
void remover_sala(MYSQL *conn);
//remover o armario apos a verificacao de se o armario esteja sendo usado ou alugado por um aluno
void remover_armario(MYSQL *conn);
//remover o computador apos a verificacao de se o computador esteja sendo usado ou alugado por um aluno
void remover_computador(MYSQL *conn);

#endif
