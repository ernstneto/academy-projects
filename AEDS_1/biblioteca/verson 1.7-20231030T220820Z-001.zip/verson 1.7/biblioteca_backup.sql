drop schema if exists biblioteca;
create database if not exists biblioteca;
use biblioteca;

drop table if exists Administrador;
create table if not exists Administrador(
	login varbinary(255) not null unique,
    senha varbinary(255) not null,
    constraint PK_Administrador primary key (login)
);

insert into Administrador(login,senha) values(aes_encrypt('cefet','cefet10'),aes_encrypt('cefet10','cefet10'));

drop table if exists Aluno;
create table if not exists Aluno(
	matricula varbinary(255) not null,
    nome varbinary(255) default null,
    constraint PK_Aluno primary key (matricula)
);

insert into Aluno(matricula,nome) values(aes_encrypt('1620340GCOM','cefet10'),aes_encrypt('Ernst','cefet10'));
insert into Aluno(matricula,nome) values(aes_encrypt('2201222GCOM','cefet10'),aes_encrypt('Peter','cefet10'));
insert into Aluno(matricula,nome) values(aes_encrypt('2202120GCOM','cefet10'),aes_encrypt('Thiago','cefet10'));
insert into Aluno(matricula,nome) values(aes_encrypt('2101100GCOM','cefet10'),aes_encrypt('Guilherme','cefet10'));
insert into Aluno(matricula,nome) values(aes_encrypt('1912100GCOM','cefet10'),aes_encrypt('Vinicius','cefet10'));

drop table if exists Livro;
create table if not exists Livro(
	nome varchar(100) not null,
    ano integer not null,
    categoria varchar(50) not null,
    estado varchar(100) not null check(estado = 'livre' or estado = 'alugado'),
    id_livro integer not null auto_increment,
    id_aluno varbinary(255) null,
    constraint PK_Livro primary key (id_livro)
);

insert into Livro(nome,ano,categoria,estado) values('Calculo I','2022','matematica','livre');
insert into Livro(nome,ano,categoria,estado) values('Calculo I','2022','matematica','livre');
insert into Livro(nome,ano,categoria,estado) values('Calculo I','2022','matematica','livre');
insert into Livro(nome,ano,categoria,estado) values('Calculo II','2022','matematica','livre');
insert into Livro(nome,ano,categoria,estado) values('Calculo II','2022','matematica','livre');
insert into Livro(nome,ano,categoria,estado) values('Calculo II','2022','matematica','livre');
insert into Livro(nome,ano,categoria,estado) values('Calculo III','2022','matematica','livre');
insert into Livro(nome,ano,categoria,estado) values('Calculo III','2022','matematica','livre');
insert into Livro(nome,ano,categoria,estado) values('Calculo III','2022','matematica','livre');
insert into Livro(nome,ano,categoria,estado) values('Fisica I','2018','fisica','livre');
insert into Livro(nome,ano,categoria,estado) values('Fisica I','2018','fisica','livre');
insert into Livro(nome,ano,categoria,estado) values('Fisica I','2018','fisica','livre');
insert into Livro(nome,ano,categoria,estado) values('Fisica II','2018','fisica','livre');
insert into Livro(nome,ano,categoria,estado) values('Fisica II','2018','fisica','livre');
insert into Livro(nome,ano,categoria,estado) values('Fisica III','2018','fisica','livre');
insert into Livro(nome,ano,categoria,estado) values('Fisica III','2018','fisica','livre');
insert into Livro(nome,ano,categoria,estado) values('Algoritmos I','2019','computacao','livre');
insert into Livro(nome,ano,categoria,estado) values('Algoritmos I','2019','computacao','livre');
insert into Livro(nome,ano,categoria,estado) values('Algoritmos I','2019','computacao','livre');
insert into Livro(nome,ano,categoria,estado) values('Algoritmos II','2019','computacao','livre');
insert into Livro(nome,ano,categoria,estado) values('Algoritmos II','2019','computacao','livre');
insert into Livro(nome,ano,categoria,estado) values('Algoritmos II','2019','computacao','livre');
insert into Livro(nome,ano,categoria,estado) values('Arquitetura de computadores','2022','computacao','livre');
insert into Livro(nome,ano,categoria,estado) values('Arquitetura de computadores','2022','computacao','livre');
insert into Livro(nome,ano,categoria,estado) values('Arquitetura de computadores','2022','computacao','livre');
insert into Livro(nome,ano,categoria,estado) values('Algoritmos II','2022','computacao','livre');
insert into Livro(nome,ano,categoria,estado) values('Algoritmos II','2022','computacao','livre');
insert into Livro(nome,ano,categoria,estado) values('Algoritmos II','2022','computacao','livre');

drop table if exists Sala;
create table if not exists Sala(
    id_sala integer not null auto_increment,
    estado varchar (20) check(estado = 'livre' or estado = 'ocupado'),
    id_aluno varbinary(255) null,
    constraint PK_Sala primary key (id_sala)
);

insert into Sala(estado) values('livre');
insert into Sala(estado) values('livre');
insert into Sala(estado) values('livre');
insert into Sala(estado) values('livre');
insert into Sala(estado) values('livre');

drop table if exists Computador;
create table if not exists Computador(
    id_computador integer not null auto_increment,
    estado varchar (20) check(estado = 'livre' or estado = 'ocupado'),
    id_aluno varbinary(255) null,
	constraint PK_Computador primary key (id_computador)
);

insert into Computador(estado) values('livre');
insert into Computador(estado) values('livre');
insert into Computador(estado) values('livre');
insert into Computador(estado) values('livre');
insert into Computador(estado) values('livre');
insert into Computador(estado) values('livre');
insert into Computador(estado) values('livre');
insert into Computador(estado) values('livre');
insert into Computador(estado) values('livre');
insert into Computador(estado) values('livre');

drop table if exists Armario;
create table if not exists Armario(
    id_armario integer not null auto_increment,
    estado varchar (20) check(estado = 'livre' or estado = 'ocupado'),
    id_aluno varbinary(255) null,
    constraint PK_Armario primary key (id_armario)
);

insert into Armario(estado) values('livre');
insert into Armario(estado) values('livre');
insert into Armario(estado) values('livre');
insert into Armario(estado) values('livre');
insert into Armario(estado) values('livre');
insert into Armario(estado) values('livre');
insert into Armario(estado) values('livre');
insert into Armario(estado) values('livre');
insert into Armario(estado) values('livre');
insert into Armario(estado) values('livre');
