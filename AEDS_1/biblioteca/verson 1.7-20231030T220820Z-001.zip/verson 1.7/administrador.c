#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mysql/mysql.h>
#include "administrador.h"

int autenticacao_administrador(char * root,char *senha, MYSQL *conn){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resposta;
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[600];
		sprintf(query,"SELECT AES_DECRYPT(login,'cefet10') as login, AES_DECRYPT(senha,'cefet10') as senha FROM Administrador where login = AES_ENCRYPT('%s','cefet10') and senha = AES_ENCRYPT('%s','cefet10') ;",root,senha);
		//puts(query);
		//mysql_query(conn,query);
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			resposta = 0;
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp != NULL){
				campos = mysql_fetch_fields(resp);
				if(campos){
					printf("Login sucesso, bem vindo administrador!\n");
					resposta = 0;
				}
				else{
					printf("root ou senha incorreta!\n");
					resposta = 1;
				}
				mysql_free_result(resp);
				return resposta;
			}
		}
	}
	else{
		printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
		resposta = 1;
	}
	mysql_close(conn);
	return resposta;
}

int etapa_acesso_administrador(MYSQL *conn){
	MYSQL_RES *res;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int op = 1;
	while(op==1){
		printf("Insira o login e senha para entrar como administrador.\n");
		printf("Etapa obrigatoria!\nDeseja continuar, digite 1.\n");
		printf("Caso deseja abortar ou retornar, digite 0.\n");
		int operacao = -1;
		printf("Opcao: ");
		scanf("%d",&operacao);
		if(operacao == 0){
			return -1;
		}
		else if(operacao != 0 && operacao != 1){
			printf("Comando invalido!\n");
		}
		while(operacao == 1){
			char root[20];
			char senha[32];
			printf("root: ");
			scanf("%s",root);
			printf("senha: ");
			scanf("%s",senha);
			int res = autenticacao_administrador(root,senha,conn);
			if(res == 0){
				//op = 0;
				//operacao = 0;
				mysql_close(conn);
				return 0;
			}
			else{
				printf("Deseja tentar novamente, digite 1\n");
				printf("Dejesa cancelar, digite 0.\n");
				scanf("%d",&operacao);
				if(operacao == 0){
					mysql_close(conn);
					return 1;
				}
			}
		}
	}
}
