#ifndef ADIMIN_H
#define ADIMIN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mysql/mysql.h>
#include "administrador.h"
//buscar pela matricula do aluno
int buscar_aluno(MYSQL *conn,char matricula[15]);
//buscar pelo aluno com pedencias na biblioteca com atribuicoes referente a tabel, estado e o id do aluno pois e igual a sua matricula 
int buscar_aluno_biblioteca(MYSQL *conn, char matricula[15],char *tabela,char *estado,char *id);
//fazer busca pelo livro de acordo com o ID do livro ou categoria, esta implicito na variavel ponteiro tabela
int buscar_livro(MYSQL *conn,char id_livro[100], char * tabela);
int buscar_livro_2(MYSQL *conn,char id_livro[100], char * tabela);
//buscar por 
int buscar_livro_aluno(MYSQL *conn,char id_livro[100]);
//buscar por ID do computador
int buscar_computador(MYSQL *conn,char id_computador[100]);
//buscar 
int buscar_computador_aluno(MYSQL *conn,char matricula[15]);
//buscar por ID do armario
int buscar_armario(MYSQL *conn,char id_armario[100]);
//buscar por ID da sala
int buscar_sala(MYSQL *conn,char id_sala[100]);
//buscar e verificar se o livro esta livre e possa ser alugado
int buscar_livro_alugar(MYSQL *conn,char id_livro[100]);
//buscar e verificar se o livro esta alugado e possa ser devolvido
int buscar_livro_devolver(MYSQL *conn,char id_livro[100]);
//buscar por todos os alunos da biblioteca
void buscar_todos_alunos(MYSQL *conn);
//buscar por todos os livros da biblioteca
void buscar_todos_livros(MYSQL *conn);
//buscar por todos os armarios da biblioteca
void buscar_todos_armarios(MYSQL *conn);
//buscar por todas as salas da biblioteca
void buscar_todos_salas(MYSQL *conn);
//buscar por todos os computadores da biblioteca
void buscar_todos_computadores(MYSQL *conn);
//buscar pedecias do aluno
int buscar_aluno_biblioteca_id_livro(MYSQL *conn,char matricula[15]);
int buscar_aluno_biblioteca_id_sala(MYSQL *conn,char matricula[15]);
int buscar_aluno_biblioteca_id_armario(MYSQL *conn,char matricula[15]);
int buscar_aluno_biblioteca_id_computador(MYSQL *conn,char matricula[15]);
#endif
