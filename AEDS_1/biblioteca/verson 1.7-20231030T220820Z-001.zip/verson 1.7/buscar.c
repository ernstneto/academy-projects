#ifndef BUSCAR_H
#define BUSCAR_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mysql/mysql.h>
#include "buscar.h"
#include "administrador.h"

int buscar_aluno(MYSQL *conn,char matricula[15]){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[300];

		sprintf(query,"select AES_DECRYPT(matricula, 'cefet10') as matricula, AES_DECRYPT(nome, 'cefet10') as nome from Aluno where matricula = AES_ENCRYPT('%s', 'cefet10');",matricula);
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			mysql_close(conn);
			return -1;
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp != NULL){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp)) != NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
				}
				if((linhas=mysql_fetch_row(resp))!= NULL){
					mysql_close(conn);
					return 0;
				}
				if((linhas=mysql_fetch_row(resp))== NULL){
					mysql_close(conn);
					return 1;
				}
			}
			else{
				mysql_close(conn);
				return -1;
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		if(mysql_errno(conn))
			printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
		mysql_close(conn);
		return -1;
	}
	mysql_close(conn);
	printf("\n");
}

void buscar_todos_alunos(MYSQL *conn){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[300];
		sprintf(query,"SELECT AES_DECRYPT(matricula,'cefet10') as matricula, AES_DECRYPT(nome,'cefet10') as nome FROM Aluno;");
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			mysql_close(conn);
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp))!= NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
				}
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		if(mysql_errno(conn))
			printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
	}
	mysql_close(conn);
	printf("\n");
}

int buscar_aluno_biblioteca_id_livro(MYSQL *conn,char matricula[15]){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	printf("%s\n",matricula);
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[500];
		sprintf(query,"SELECT AES_DECRYPT(id_aluno,'cefet10') as id_aluno,estado,id_livro FROM Livro where id_aluno = AES_ENCRYPT('%s','cefet10') and estado = 'alugado';",matricula);
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			mysql_close(conn);
			return -1;
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp))!= NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
				}
				if((linhas=mysql_fetch_row(resp))!= NULL){
					mysql_close(conn);
					return 0;
				}
				else if((linhas=mysql_fetch_row(resp))== NULL){
					mysql_close(conn);
					return 1;
				}
			}
			else{
				mysql_close(conn);
				return -1;
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		if(mysql_errno(conn))
			printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
		mysql_close(conn);
		return -1;
	}
	mysql_close(conn);
	printf("\n");
}

int buscar_aluno_biblioteca_id_sala(MYSQL *conn,char matricula[15]){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	printf("%s\n",matricula);
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[500];
		sprintf(query,"SELECT AES_DECRYPT(id_aluno,'cefet10') as id_aluno,estado,id_sala FROM Sala where id_aluno = AES_ENCRYPT('%s','cefet10') and estado = 'ocupado';",matricula);
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			mysql_close(conn);
			return -1;
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp))!= NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
				}
				if((linhas=mysql_fetch_row(resp))!= NULL){
					mysql_close(conn);
					return 0;
				}
				else if((linhas=mysql_fetch_row(resp))== NULL){
					mysql_close(conn);
					return 1;
				}
			}
			else{
				mysql_close(conn);
				return -1;
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		if(mysql_errno(conn))
			printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
		mysql_close(conn);
		return -1;
	}
	mysql_close(conn);
	printf("\n");
}

int buscar_aluno_biblioteca_id_armario(MYSQL *conn,char matricula[15]){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	printf("%s\n",matricula);
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[500];
		sprintf(query,"SELECT AES_DECRYPT(id_aluno,'cefet10') as id_aluno,estado,id_armario FROM Armario where id_aluno = AES_ENCRYPT('%s','cefet10') and estado = 'ocupado';",matricula);
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			mysql_close(conn);
			return -1;
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp))!= NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
				}
				if((linhas=mysql_fetch_row(resp))!= NULL){
					mysql_close(conn);
					return 0;
				}
				else if((linhas=mysql_fetch_row(resp))== NULL){
					mysql_close(conn);
					return 1;
				}
			}
			else{
				mysql_close(conn);
				return -1;
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		if(mysql_errno(conn))
			printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
		mysql_close(conn);
		return -1;
	}
	mysql_close(conn);
	printf("\n");
}

int buscar_aluno_biblioteca_id_computador(MYSQL *conn,char matricula[15]){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	printf("%s\n",matricula);
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[500];
		sprintf(query,"SELECT AES_DECRYPT(id_aluno,'cefet10') as id_aluno,estado,id_computador FROM Computador where id_aluno = AES_ENCRYPT('%s','cefet10') and estado = 'ocupado';",matricula);
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			mysql_close(conn);
			return -1;
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp))!= NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
				}
				if((linhas=mysql_fetch_row(resp))!= NULL){
					mysql_close(conn);
					return 0;
				}
				else if((linhas=mysql_fetch_row(resp))== NULL){
					mysql_close(conn);
					return 1;
				}
			}
			else{
				mysql_close(conn);
				return -1;
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		if(mysql_errno(conn))
			printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
		mysql_close(conn);
		return -1;
	}
	mysql_close(conn);
	printf("\n");
}

int buscar_livro(MYSQL *conn,char id_livro[100], char * tabela){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	//acessar o banco de dados
	//abrindo
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[300];
		sprintf(query,"SELECT nome,ano,categoria,estado,AES_DECRYPT(id_aluno,'cefet10') as id_aluno FROM Livro where %s = '%s';",tabela, id_livro);
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			resultado = -1;
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp))!= NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
					resultado = 0;
				}
				if((linhas=mysql_fetch_row(resp))== NULL){
					mysql_close(conn);
					return 1;
				}
				else if((linhas=mysql_fetch_row(resp))!= NULL){
					mysql_close(conn);
					return 0;
				}
			}
			else if(resp == NULL){
				mysql_close(conn);
				return -1;
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		if(mysql_errno(conn))
			printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
		mysql_close(conn);
		return -1;
	}
	mysql_close(conn);
	printf("\n");
}

int buscar_livro_2(MYSQL *conn,char id_livro[100], char * tabela){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	//acessar o banco de dados
	//abrindo
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[300];
		sprintf(query,"SELECT * FROM Livro where %s = '%s';",tabela, id_livro);
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			mysql_close(conn);
			return -1;
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp))!= NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
					resultado = 0;
				}
				if((linhas=mysql_fetch_row(resp))== NULL){
					mysql_close(conn);
					return 1;
				}
				else if((linhas=mysql_fetch_row(resp))!= NULL){
					mysql_close(conn);
					return 0;
				}
			}
			else if(resp == NULL){
				mysql_close(conn);
				return -1;
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		if(mysql_errno(conn))
			printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
		mysql_close(conn);
		return -1;
	}
	mysql_close(conn);
	printf("\n");
	//return resultado;
}
void buscar_todos_livros(MYSQL *conn){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[300];
		sprintf(query,"SELECT nome,ano,categoria,estado,id_livro,AES_DECRYPT(id_aluno,'cefet10') as id_aluno FROM Livro;");
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			resultado = 1;
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp))!= NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
				}
				resultado = 1;
			}
			else{
				resultado = 0;
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		if(mysql_errno(conn))
			printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
		resultado = 0;
	}
	mysql_close(conn);
	printf("\n");
}

int buscar_livro_aluno(MYSQL *conn,char id_livro[15]){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[300];
		sprintf(query,"SELECT nome,ano,categoria,id_livro,estado,id_aluno FROM livro where id_livro = '%s' and id_aluno IS NULL",id_livro);
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			resultado = -1;
		}
		else{ 
			resp = mysql_store_result(conn);//recebe a consulta
			//caso res for diferente de 0, ele foi encontrado
			if(resp){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				if((linhas=mysql_fetch_row(resp))== NULL){
					mysql_close(conn);
					return 1;
				}
				while((linhas=mysql_fetch_row(resp))!= NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
					resultado = 0;
				}
			}
			//caso res for 0, ele nao foi encontrado
			else{
				resultado = 1;
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		if(mysql_errno(conn))
			printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
		resultado = -1;
		}
	mysql_close(conn);
	printf("\n");
	return resultado;
}

int buscar_computador(MYSQL *conn,char id_computador[100]){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		puts("Buscando um computador: ");
		//acessar o banco de dados
		char query[300];
		sprintf(query,"SELECT id_computador,estado,AES_DECRYPT(id_aluno,'cefet10') as id_aluno FROM Computador where id_computador = '%s';",id_computador);
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			mysql_close(conn);
			return 1;
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp != NULL){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp)) != NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
					resultado = 0;
				}
				if((linhas=mysql_fetch_row(resp))== NULL){
					mysql_close(conn);
					return 1;
				}
				else if((linhas=mysql_fetch_row(resp))!= NULL){
					mysql_close(conn);
					return 0;
				}
			}
		}
	}
	mysql_close(conn);
	printf("\n");
	//return resultado;
}

int buscar_armario(MYSQL *conn,char id_armario[100]){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	printf("Buscando um armario:\n");
	//acessar o banco de dados
	char query[300];
	sprintf(query,"SELECT id_armario,estado,AES_DECRYPT(id_aluno,'cefet10') as id_aluno FROM Armario where id_armario = '%s';",id_armario);
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		if(mysql_query(conn,query)){
			printf("Erro: %s\n",mysql_error(conn));
			resultado = 1;
		}
		else{
			resp = mysql_store_result(conn);
			if(resp){
				campos = mysql_fetch_fields(resp);
					for(int conta = 0; conta< mysql_num_fields(resp);conta++){
						printf("%s \t",campos[conta].name);
					}
					if(mysql_num_fields(resp)>1){
						printf("\t");
					}
					printf("\n");
					while((linhas=mysql_fetch_row(resp))!= NULL){
						for(int conta = 0; conta < mysql_num_fields(resp);conta++){
							printf("%s \t",linhas[conta]);
						}
						printf("\n");
						resultado = 0;
					}
					if((linhas=mysql_fetch_row(resp))== NULL){
						mysql_close(conn);
						return 1;
					}
					else if((linhas=mysql_fetch_row(resp))!= NULL){
						mysql_close(conn);
						return 0;
					}
				}
				else{
					mysql_close(conn);
						return -1;
				}
		}
	}
	mysql_close(conn);
	printf("\n");
	//return resultado;
}

void buscar_todos_computadores(MYSQL *conn){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[300];
		sprintf(query,"SELECT id_computador,estado, AES_DECRYPT(id_aluno,'cefet10') as id_aluno FROM Computador;");
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			resultado = 1;
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp))!= NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
				}
				resultado = 1;
			}
			else{
				resultado = 0;
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		if(mysql_errno(conn))
			printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
		resultado = 0;
	}
	mysql_close(conn);
	printf("\n");
}

int buscar_sala(MYSQL *conn,char id_sala[100]){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Buscando uma sala:\n");
		//acessar o banco de dados
		char query[400];
		sprintf(query,"SELECT id_sala, estado, AES_DECRYPT(id_aluno,'cefet10') as id_aluno FROM Sala where id_sala = '%s';",id_sala);
		//printf("%s\n",query);
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			mysql_close(conn);
			return -1;
			//printf("%d\n",resultado);
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp){
			//printf("asd\n");
				campos = mysql_fetch_field(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",(campos[conta].name));
					if(mysql_num_fields(resp)>1){
						printf("\t");
					}
					while((linhas=mysql_fetch_row(resp))!=NULL){
						for(conta = 0; conta< mysql_num_fields(resp);conta++){
							printf("%s \t",linhas[conta]);
						}
						printf("\n");
						resultado = 0;
					}
					if((linhas=mysql_fetch_row(resp))== NULL){
						mysql_close(conn);
						return 1;
					}
					else if((linhas=mysql_fetch_row(resp))!= NULL){
						mysql_close(conn);
						return 0;
					}
				}
				mysql_free_result(resp);
			}
			else{
				mysql_close(conn);
				return 1;
				}
		}
	}
	mysql_close(conn);
	printf("\n");
	//return resultado;
}

void buscar_todos_salas(MYSQL *conn){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[300];
		sprintf(query,"SELECT id_sala,estado,AES_DECRYPT(id_aluno,'cefet10') as id_aluno FROM Sala;");
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			mysql_close(conn);
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp))!= NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
				}
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		if(mysql_errno(conn))
			printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
	}
	mysql_close(conn);
	printf("\n");
}

void buscar_todos_armarios(MYSQL *conn){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[300];
		sprintf(query,"SELECT id_armario,estado,AES_DECRYPT(id_aluno,'cefet10') as id_aluno FROM Armario;");
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			mysql_close(conn);
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp))!= NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
				}
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		if(mysql_errno(conn))
			printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
	}
	mysql_close(conn);
	printf("\n");
}

int buscar_livro_alugar(MYSQL *conn, char id_livro[100]){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado = -1;
	//acessar o banco de dados
	//abrindo
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[300];
		sprintf(query,"SELECT nome,ano,categoria,id_livro,estado,AES_DECRYPT(id_aluno,'cefet10') as id_aluno FROM Livro where id_livro = '%s' and estado = 'livre';",id_livro);
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			resultado = -1;
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp))!= NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
					resultado = 0;
				}
				if((linhas=mysql_fetch_row(resp))== NULL){
					mysql_close(conn);
					return 1;
				}
				else if((linhas=mysql_fetch_row(resp))!= NULL){
					mysql_close(conn);
					return 0;
				}
			}
			else{
				mysql_close(conn);
				return -1;
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		if(mysql_errno(conn))
			printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
		mysql_close(conn);
		return -1;
	}
	mysql_close(conn);
	printf("\n");
	//return resultado;
}

int buscar_livro_devolver(MYSQL *conn, char id_livro[100]){
	MYSQL_RES *resp;
	MYSQL_ROW linhas;
	MYSQL_FIELD *campos;
	int resultado;
	//acessar o banco de dados
	//abrindo
	if(mysql_real_connect(conn,"localhost","root","ernst5897","biblioteca",0,NULL,0)){
		printf("Conectado com sucesso!\n");
		//buscar
		char query[300];
		sprintf(query,"SELECT nome,ano,categoria,id_livro,estado,AES_DECRYPT(id_aluno,'cefet10') as id_aluno FROM Livro where id_livro = '%s' and estado = 'alugado';",id_livro);
		if(mysql_query(conn,query)){
			printf("Erro %s\n",mysql_error(conn));
			resultado = -1;
		}
		else{
			resp = mysql_store_result(conn);//recebe a consulta
			if(resp){
				campos = mysql_fetch_fields(resp);
				for(int conta = 0; conta< mysql_num_fields(resp);conta++){
					printf("%s \t",campos[conta].name);
				}
				if(mysql_num_fields(resp)>1){
					printf("\t");
				}
				printf("\n");
				while((linhas=mysql_fetch_row(resp))!= NULL){
					for(int conta = 0; conta < mysql_num_fields(resp);conta++){
						printf("%s \t",linhas[conta]);
					}
					printf("\n");
					resultado = 0;
				}
				if((linhas=mysql_fetch_row(resp))== NULL){
					mysql_close(conn);
					return 1;
				}
			}
			else{
				resultado = 1;
			}
		}
	}
	else{
		printf("Conexao falhou\n");
		printf("Erro %d: %s\n",mysql_errno(conn),mysql_error(conn));
		resultado = -1;
	}
	mysql_close(conn);
	printf("\n");
	return resultado;
}
#endif
