#ifndef ADMINISTRADOR_H
#define ADMINISTRADOR_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mysql/mysql.h>
//autenticar os dados para o acesso do administrador da biblioteca
int autenticacao_administrador(char * user,char *senha, MYSQL *conn);
//etapa de entrada de dados de login e senha
int etapa_acesso_administrador(MYSQL *conn);

#endif
